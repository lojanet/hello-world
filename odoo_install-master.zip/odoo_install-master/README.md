odoo_install
============

script for ubuntu
